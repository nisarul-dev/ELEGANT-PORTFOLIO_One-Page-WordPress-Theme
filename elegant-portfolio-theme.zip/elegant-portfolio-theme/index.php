<?php
// Silence is sorrow.